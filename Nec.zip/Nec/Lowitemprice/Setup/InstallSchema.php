<?php namespace Nec\Lowitemprice\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        $installer->getConnection()->addColumn(
            $installer->getTable('salesrule'),
            'cartitems_limit',
            [
                'type'      => Table::TYPE_TEXT,
                'length'    => '11',
                'nullable'  => false,
                'default'   => '0',
                'comment'   => 'Cart Items Limits'
            ]
        );

        $installer->endSetup();
    }
}
