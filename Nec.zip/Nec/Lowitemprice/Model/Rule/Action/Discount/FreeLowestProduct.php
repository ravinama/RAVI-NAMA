<?php

namespace Nec\Lowitemprice\Model\Rule\Action\Discount;

use Magento\Checkout\Model\Session as checkoutSession;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Quote\Model\Quote\Item\AbstractItem;
use Magento\SalesRule\Model\Rule;
use Magento\SalesRule\Model\Rule\Action\Discount\AbstractDiscount;
use Magento\SalesRule\Model\Rule\Action\Discount\Data as DiscountData;
use Magento\SalesRule\Model\Rule\Action\Discount\DataFactory;
use Magento\SalesRule\Model\Validator;

class FreeLowestProduct extends AbstractDiscount {

    /**
     * @var checkoutSession
     */
    protected $checkoutSession;

    /**
     * FreeLowestProduct constructor.
     *
     * @param Validator $validator
     * @param DataFactory $discountDataFactory
     * @param PriceCurrencyInterface $priceCurrency
     * @param checkoutSession $checkoutSession
     */
    public function __construct(
        Validator $validator,
        DataFactory $discountDataFactory,
        PriceCurrencyInterface $priceCurrency,
        checkoutSession $checkoutSession
    ) {
        $this->checkoutSession = $checkoutSession;
        parent::__construct(
            $validator,
            $discountDataFactory,
            $priceCurrency
        );
    }

    /**
     * @param \Magento\SalesRule\Model\Rule $rule
     * @param \Magento\Quote\Model\Quote\Item\AbstractItem $item
     * @param float $qty
     * @return Data
     */
    public function calculate($rule, $item, $qty) {
        $checkouSession = $this->checkoutSession->getQuote();
        $cartItems = $checkouSession->getAllVisibleItems();
        $itemCount = $checkouSession->getItemsCount();
        $totalItemCount = $checkouSession->getItemsSummaryQty();
        $cartitemsLimit = $rule->getCartitemsLimit();
        /** @var \Magento\SalesRule\Model\Rule\Action\Discount\Data $discountData */
        $discountData = $this->discountFactory->create();
        if($totalItemCount > $cartitemsLimit){
            $prices = [];
            foreach ($cartItems as $item) {
                $prices[] = $item->getPrice();
            }
            $mindiscountAmount = min($prices);
            $quoteAmount = $this->priceCurrency->convert($mindiscountAmount, $item->getQuote()->getStore());
            $discountAmount = $quoteAmount/$itemCount;
            $discountData->setAmount($discountAmount);
            $discountData->setBaseAmount($discountAmount);
        }
        return $discountData;
    }
}
