<?php namespace Nec\Lowitemprice\Plugin\Rule\Metadata;

class ValueProvider {
    public function afterGetMetadataValues(
        \Magento\SalesRule\Model\Rule\Metadata\ValueProvider $subject,
        $result
    ) {
        $applyOptions = [
            'label' => __('Free Items'),
            'value' => [
                [
                    'label' => 'Free item of lowest price',
                    'value' => 'free_lowset',
                ],
            ],
        ];
        array_push($result['actions']['children']['simple_action']['arguments']['data']['config']['options'], $applyOptions);
        return $result;
    }
}