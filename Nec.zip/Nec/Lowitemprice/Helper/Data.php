<?php
namespace Nec\Lowitemprice\Helper;

use Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
    protected $_cart;

    protected $_http;

    protected $_customerSession;

    protected $_resource;

    /**
    * @param \Magento\Framework\App\Helper\Context $context
    */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Framework\App\Request\Http $http,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\App\ResourceConnection $resource
    ) {
        $this->_cart = $cart;
        $this->_http = $http;
        $this->_customerSession = $customerSession;
        $this->_resource = $resource;
        parent::__construct($context);
    }

}